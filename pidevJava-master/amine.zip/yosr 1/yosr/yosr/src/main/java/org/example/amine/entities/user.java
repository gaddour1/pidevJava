package org.example.amine.entities;

public class user {
}
