package org.example.amine.tests;


public class Main {
    public static void main(String[] args) {

     /*   serviceEvenement sp = new serviceEvenement();


        try {
            System.out.println(sp.getAll());
            event eq = new event("t","t", "l","1/1/2000");
             sp.ajouter(eq);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
*/
        //Equipement eq = new Equipement("tapis","behia","doc","ff","cat",16);
        // Equipement eq1 = new Equipement(6,"tapisss","behia","doc","hiii","ee",10);
        // sp.ajouter(eq);


    }
}
